from pasek import pasek
from pasek import superpasek
from pasek import propasek
from pasek import ultrapasek
from pasek import ultrapropasek